public class BadHeightException extends Exception {

    public BadHeightException(String message)
    {
        super(message);
    }
}

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public class RoomWriter {

    // create a class called RoomWriter with one method
    // writing to a file: FileOutputStream
    public static void writeRoomFile(String fileName, List<Room> roomList) {

        try {
            FileOutputStream fileOut = new FileOutputStream(fileName);
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);

            for(Room aRoom : roomList)
            {
                objectOut.writeObject(aRoom);
            }

            objectOut.close();
            System.out.println("The object was successfully written to a file");
        }

        catch (Exception ex) {
            ex.printStackTrace();

        }
    }
}

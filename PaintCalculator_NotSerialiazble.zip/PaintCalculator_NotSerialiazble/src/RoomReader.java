import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

// create a class called RoomReader with one method
// reading to a file: FileInputStream
public class RoomReader {

    public static List<Room> readRoomFile(String fileName) {

        ObjectInputStream ois = null;

        try {
            ois = new ObjectInputStream(new FileInputStream(fileName));
        }

        catch (IOException e){
            e.printStackTrace();
        }

        List<Room> roomList = new ArrayList<>();
        Object obj = null;

        try {
          // allow the EOF exception to happen
            while ((obj = ois.readObject()) != null) {
                Room room = (Room) obj;
                roomList.add(room);
            }

            ois.close();

        }

        catch (Exception e)
        {
         // do nothing, we expect this to happen
        }

        return roomList;

    }

}

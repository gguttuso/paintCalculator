public class myChoice implements Paintable {


    @Override
    public double getPremiumCost() {
        return 11;
    }

    @Override
    public double getStandardCost() {
        return 7;
    }
}

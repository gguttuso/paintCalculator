public class BadWidthException extends Exception {

    public BadWidthException(String message)
    {
        super(message);
    }
}
